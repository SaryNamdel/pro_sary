class ImagesDTO:
    def __init__(self, imgId, apartmentId, imgName):
        self.imgId = imgId
        self.apartmentId = apartmentId
        self.imgName = imgName
