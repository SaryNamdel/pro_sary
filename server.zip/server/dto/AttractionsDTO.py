class AttractionsDTO:
    def __init__(self, attractionId, trampoline, hammock, woodenBench, SittingArea, isPool):
        self.attractionId = attractionId
        self.trampoline = trampoline
        self.hammock = hammock
        self.woodenBench = woodenBench
        self.SittingArea = SittingArea
        self.isPool = isPool
