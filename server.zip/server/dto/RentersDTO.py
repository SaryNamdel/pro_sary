class RentersDTO:
    def __init__(self, rentId, apartmentId, lastName, firstName, phone, email, pwd):
        self.rentId = rentId
        self.apartmentId = apartmentId
        self.lastName = lastName
        self.firstName = firstName
        self.phone = phone
        self.email = email
        self.pwd = pwd

