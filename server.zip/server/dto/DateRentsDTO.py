class DateRentsDTO:
    def __init__(self, detailsRentId, dateIncoming, dateExit):
        self.detailsRentId = detailsRentId
        self.dateIncoming = dateIncoming
        self.dateExit = dateExit
