class CityDTO:
    def __init__(self, cityId, areaId, cityName):
        self.cityId = cityId
        self.areaId = areaId
        self.cityName = cityName