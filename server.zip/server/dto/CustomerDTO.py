class CustomerDTO:
    def __init__(self, custId, cityId, lastName, firstName, phone, email, pwd):
        self.custId = custId
        self.cityId = cityId
        self.lastName = lastName
        self.firstName = firstName
        self.phone = phone
        self.email = email
        self.pwd = pwd

