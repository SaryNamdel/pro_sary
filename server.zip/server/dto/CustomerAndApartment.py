class CustomerAndApartmentDTO:
    def __init__(self, customerAndApartmentId, apartmentId, custId,rentId, dateIncoming, dateExit):
        self.customerAndApartmentId = customerAndApartmentId
        self.apartmentId = apartmentId
        self.rentId = rentId
        self.custId = custId
        self.dateIncoming = dateIncoming,
        self.dateExit = dateExit


