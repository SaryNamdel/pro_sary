class AreaDTO:
    def __init__(self, areaId, areaName):
        self.areaId = areaId
        self.areaName = areaName

