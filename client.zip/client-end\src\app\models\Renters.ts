export class Renters{
    rentId:number=0
    apartmentId:number=0
    lastName:string = ''
    firstName:string = ''
    phon:string=''
    email:string=''
    pwd:string=''


    constructor( rentId:number,apartmentId:number ,lastName:string,
        firstName:string,  phon:string ,email:string, pwd:string       ){
            this.rentId=rentId
            this.apartmentId=apartmentId
            this.lastName=lastName
            this.firstName=firstName
            this.phon=phon
            this.email=email
            this.pwd=pwd
}

   

}