
export class Image{
    imgId:number=0
    apartmentId:string=''
    imgName:string=''

    constructor(imgId:number,apartmentId:string,imgName:string){
        this.imgId=imgId
        this.apartmentId=apartmentId
        this.imgName=imgName
    }

}