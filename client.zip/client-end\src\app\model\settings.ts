export interface SettingsConfig {
    numRows?: number;
}
