export enum RenterStatus {
    register = 'רישום משכיר',
    exist = 'סטטוס משכיר'
}


export enum CustomerStatus {
    register = 'רישום לקוח',
    exist = 'סטטוס לקוח'
} 