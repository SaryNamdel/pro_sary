
export class Area{
    areaId:number=0
    areaName:string=''

    constructor(areaId:number,areaName:string){
        this.areaId=areaId
        this.areaName=areaName
    }

}