export interface Apartment {
    city: string;
    images: [];
}
