
export class Cities {
    cityId: number = 0
    areaId: string = ''
    cityName: string = ''

    constructor(cityId: number, areaId: string, cityName: string,) {
        this.cityId = cityId
        this.cityName = cityName
        this.areaId = areaId
    }

}