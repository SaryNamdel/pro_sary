export interface IpConfig {
    servicePath?: string;
}
