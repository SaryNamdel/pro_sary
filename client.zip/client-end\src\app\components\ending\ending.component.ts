import { Component } from '@angular/core';

@Component({
  selector: 'app-ending',
  imports: [],
  templateUrl: './ending.component.html',
  styleUrl: './ending.component.scss'
})
export class EndingComponent {

}
